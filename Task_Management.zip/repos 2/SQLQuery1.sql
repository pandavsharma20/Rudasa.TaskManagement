Create database dbTaskManagement
Use dbTaskManagement 
Go

Create table tblTask
(
TaskId int primary key identity(1,1), 
TaskTitle varchar(100),
TaskDescription varchar(250), 
ScheduleDateTime datetime, 
IsCompleted bit, 
TaskCompletionDateTime datetime 
) 


create procedure usp_Task
@TaskId int =0,
@TaskTitle varchar(100)=null,
@TaskDescription varchar(250)=null,
@ScheduleDateTime datetime=null,
@IsCompleted bit=null,
@Action varchar(10)=null
as
begin
	if(@Action='Add')
	begin
		insert into tblTask (TaskTitle, TaskDescription, ScheduleDateTime) values (@TaskTitle, @TaskDescription, @ScheduleDateTime)
	end
	if(@Action='Update')
	begin
		update tblTask set TaskTitle=@TaskTitle, TaskDescription=@TaskDescription, ScheduleDateTime=@ScheduleDateTime where TaskId=@TaskId
	end
	if(@Action='Delete')
	begin
		delete from tblTask where TaskId=@TaskId
	end
	if(@Action='Completed')
	begin
		update tblTask set IsCompleted=@IsCompleted, TaskCompletionDateTime=GETDATE() where TaskId=@TaskId
	end

end

create procedure usp_GetTask
as
begin
	select TaskId, TaskTitle, TaskDescription, ScheduleDateTime, ISNULL(IsCompleted,0) IsCompleted, TaskCompletionDateTime from tblTask
end 


