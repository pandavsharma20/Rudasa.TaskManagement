﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_Management_Rusada.DataAccess;
using Task_Management_Rusada.Model;
using static Task_Management_Rusada.Enuerations;

namespace Task_Management_Rusada
{
    public partial class dialogAddTask : Form
    {
        public event EventHandler LoadTask;
        TaskAction taskAction;
        int taskId = 0;
        public dialogAddTask(TaskAction _taskAction, ToDoTask _task=null)
        {
            taskAction = _taskAction;
            InitializeComponent();
            if (taskAction == TaskAction.Update)
            {
                taskId = _task.TaskId;
                txtTitle.Text = _task.TaskTitle;
                txtDescription.Text = _task.TaskDescription;
                dateTimeSchedule.Value = _task.ScheduleDateTime;             
            
            }
        }

        private void dialogAddTask_Load(object sender, EventArgs e)
        {
            dateTimeSchedule.Format = DateTimePickerFormat.Custom;
            dateTimeSchedule.CustomFormat = "dd/MM/yyyy hh:mm:ss";
            dateTimeSchedule.MinDate = DateTime.Now;

        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            await PerformAction(sender, e, taskAction);


        }
        private async Task PerformAction(object sender, EventArgs e, TaskAction _taskAction)
        {
            if (string.IsNullOrEmpty(txtTitle.Text))
            {
                MessageBox.Show("Please enter title, as field value is mandatory", "Validation Error");
                txtTitle.Focus();
                return;
            }
            ToDoTask task = new ToDoTask()
            {
                 TaskId=taskId, 
                 TaskTitle=txtTitle.Text,
                 TaskDescription=txtDescription.Text,
                 ScheduleDateTime=dateTimeSchedule.Value

            };
            SqlHelper _helper = new SqlHelper();
            await _helper.SaveTask(task, _taskAction);
            LoadTask(sender, e);
            this.Close();
        
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();

        }

    }
}
