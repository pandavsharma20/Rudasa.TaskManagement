﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Task_Management_Rusada.DataAccess;
using Task_Management_Rusada.Model;
using static Task_Management_Rusada.Enuerations;

namespace Task_Management_Rusada
{
    public partial class formTaskManagement : Form
    {
        public formTaskManagement()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            dialogAddTask dialogTask = new dialogAddTask(Enuerations.TaskAction.Add);
            dialogTask.LoadTask += DialogTask_LoadTask;
            dialogTask.ShowDialog();

        }

        private void DialogTask_LoadTask(object sender, EventArgs e)
        {
            LoadTask();
        }

        private void formTaskManagement_Load(object sender, EventArgs e)
        {
            LoadTask();

        }
        private void LoadTask()
        {
            SqlHelper _helper = new SqlHelper();
            dgvSchedule.DataSource = _helper.GetTask();
            FormatDataGridView();
        
        }

        private void FormatDataGridView()
        {
            foreach (DataGridViewRow row in dgvSchedule.Rows)
            {
                if (Convert.ToDateTime(row.Cells[3].Value) < DateTime.Now && !Convert.ToBoolean(row.Cells[4].Value))
                {
                    row.DefaultCellStyle.BackColor = Color.Bisque;
                }
            }
     
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            var task = new ToDoTask()
            {
                TaskId = Convert.ToInt32(dgvSchedule.SelectedRows[0].Cells[0].Value),
                TaskTitle = Convert.ToString(dgvSchedule.SelectedRows[0].Cells[1].Value),
                TaskDescription = Convert.ToString(dgvSchedule.SelectedRows[0].Cells[2].Value),
                ScheduleDateTime = Convert.ToDateTime(dgvSchedule.SelectedRows[0].Cells[3].Value),

            };
            dialogAddTask dialogTask = new dialogAddTask(Enuerations.TaskAction.Update, task);
            dialogTask.LoadTask += DialogTask_LoadTask;
            dialogTask.ShowDialog();
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            SqlHelper helper = new SqlHelper();
            await helper.DeleteTask(Convert.ToInt32(dgvSchedule.SelectedRows[0].Cells[0].Value), TaskAction.Delete);
            LoadTask();

        }

        private async void btnCompleted_Click(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(dgvSchedule.SelectedRows[0].Cells[4].Value))
            {
                MessageBox.Show("Task already completed", "validation error");
                return;
            }
            SqlHelper helper = new SqlHelper();
            await helper.CompleteTask(Convert.ToInt32(dgvSchedule.SelectedRows[0].Cells[0].Value), TaskAction.Completed);
            LoadTask();
        }
    }
}
