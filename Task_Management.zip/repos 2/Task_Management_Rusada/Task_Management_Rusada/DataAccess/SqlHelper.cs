﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Task_Management_Rusada.Model;
using static Task_Management_Rusada.Enuerations;

namespace Task_Management_Rusada.DataAccess
{
    internal class SqlHelper
    {
        static string connectionString = "";
        static SqlHelper()
        {
            connectionString = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;

        }
        public async Task<bool> SaveTask(ToDoTask task, TaskAction _taskAction)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlParameter[] parameters = new SqlParameter[] {
                new SqlParameter(){ParameterName="@TaskId", Value=task.TaskId},
                new SqlParameter(){ParameterName="@TaskTitle", Value=task.TaskTitle},
                new SqlParameter(){ParameterName="@TaskDescription", Value=task.TaskDescription},
                new SqlParameter(){ParameterName="@ScheduleDateTime", Value=task.ScheduleDateTime},
                new SqlParameter(){ParameterName="@Action", Value=_taskAction.ToString()}
                };
                SqlCommand cmd = new SqlCommand("usp_Task");
                cmd.Parameters.AddRange(parameters);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                conn.Open();
                cmd.Connection = conn;
                var result = await cmd.ExecuteNonQueryAsync();
                conn.Close();
                if (result > 0)
                    return true;
                else
                    return false;           
            }
        }
        public async Task<bool> DeleteTask(int _taskId, TaskAction _taskAction)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlParameter[] parameters = new SqlParameter[] {
                new SqlParameter(){ParameterName="@TaskId", Value=_taskId},
                new SqlParameter(){ParameterName="@Action", Value=_taskAction.ToString()}
                };
                SqlCommand cmd = new SqlCommand("usp_Task");
                cmd.Parameters.AddRange(parameters);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                conn.Open();
                cmd.Connection = conn;
                var result = await cmd.ExecuteNonQueryAsync();
                conn.Close();
                if (result > 0)
                    return true;
                else
                    return false;
            }
        }
        public async Task<bool> CompleteTask(int _taskId, TaskAction _taskAction)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlParameter[] parameters = new SqlParameter[] {
                new SqlParameter(){ParameterName="@TaskId", Value=_taskId},
                new SqlParameter(){ParameterName="@IsCompleted", Value=1},
                new SqlParameter(){ParameterName="@Action", Value=_taskAction.ToString()}
                };
                SqlCommand cmd = new SqlCommand("usp_Task");
                cmd.Parameters.AddRange(parameters);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                conn.Open();
                cmd.Connection = conn;
                var result = await cmd.ExecuteNonQueryAsync();
                conn.Close();
                if (result > 0)
                    return true;
                else
                    return false;
            }
        }
        public DataTable GetTask()
        {

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                DataTable dt = new DataTable();
                SqlCommand cmd = new SqlCommand("usp_GetTask");
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Connection = conn;
                SqlDataAdapter adap = new SqlDataAdapter(cmd);
                adap.Fill(dt);
                return dt;
            }

        }

    }
}
